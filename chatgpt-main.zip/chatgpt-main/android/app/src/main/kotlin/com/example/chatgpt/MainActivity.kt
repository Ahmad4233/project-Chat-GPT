package com.example.chatgpt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
