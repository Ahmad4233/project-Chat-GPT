import 'package:flutter/material.dart';

class AppColor {

  static Color black = const Color(0xFF000000);
  static Color border_color = const Color(0x40000000);
  static Color white = const Color(0xFFFFFFFF);
  static Color color1 = const Color(0xFFEC4BD9);
  static Color color2 = const Color(0xFFE0BDC7);
  static Color color3 = const Color(0xFF8858E9);

}

class AppColors {

  static Color black = const Color(0xFFFFFFFF);
  static Color white = const Color(0xFF000000);

}